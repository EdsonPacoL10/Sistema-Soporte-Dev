<?php

namespace App\Controllers;
use CodeIgniter\Files\File;

class Home extends BaseController
{
    protected $helpers = ['form'];

    public function index()
    {
        return view('upload_file', ['errors' => []]);
    }

    public function upload()
    {
        $validationRule = [
            'userfile' => [
                'label' => 'Upload files',
                'rules' => 'uploaded[userfile]'
                    . '|max_size[userfile,2000]',
            ],
        ];

        if (!$this->validate($validationRule)) {
            $data = ['errors' => $this->validator->getErrors()];
            return view('upload_file', $data);
        }

        $file = $this->request->getFile('userfile');

        if (! $file->hasMoved()) {
            $newName = $file->getRandomName();
            $file->move('./file', $newName);
            
            $data = ['success' => "El archivo se subió correctamente."];
            return view('upload_file', $data);
        } else {
            $data = ['errors' => 'El archivo ya se ha movido.'];
            return view('upload_file', $data);
        }
    }
}