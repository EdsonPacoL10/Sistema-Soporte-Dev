<!doctype html>
<html lang="es">
  <head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Upload file</title>
	<link rel="stylesheet" href="<?php echo base_url('css/style.css'); ?>">
	</head>
	<body>
		<div class="card">
			<h1>Upload</h1>
            <?= form_open_multipart('home/upload') ?>
			<div class="file">
				<input type="file" name="userfile" id="fileLang" onchange="loadFile(event)">
				<label id="fileLabel" for="fileLang"></label>
			</div>
			<div id="content" class="content-file"></div>
			<div class="upload-file">
				<button type="submit">Subir archivo</button>
			</div>
		</div>
	</body>
	<script>
		var loadFile = function(event) {
			var reader = new FileReader();
			var typeFIle = event.target.files[0].type.split('/');
			var contentFile = document.getElementById('content');
			var labelFile = document.getElementById('fileLabel');
			
			labelFile.innerHTML = typeFIle[1];
			
			if(typeFIle[0]=="image"){
				reader.onload = function(){
					contentFile.innerHTML = '<img src="'+reader.result+'">';
				};
			} else {
				contentFile.innerHTML = '<img src="<?php echo base_url('file/file.svg'); ?>">';
			}

			reader.readAsDataURL(event.target.files[0]);
		};
		
		<?php if($errors): ?>
			<?php foreach($errors as $error): ?>
				alert("<?= esc($error) ?>");
    		<?php endforeach ?>
    	<?php endif; ?>

		<?php if($success): ?>
			alert("<?= esc($success) ?>");
    	<?php endif; ?>
	</script>
</html>